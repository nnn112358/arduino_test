2015-08-15 - **0.7.0**
 * Added Navigation Image [(haas85)](https://github.com/haas85/)

2015-03-09 - **0.6.0**
 * Bower support added [(aisch)](https://github.com/aisch/)

2014-08-07 - **0.5.0**
 * Added ImageMap type [(rctoris)](https://github.com/rctoris/)

2014-07-28 - **0.4.0**
 * Updated to easeljs 0.7.1 [(rctoris)](https://github.com/rctoris/)
 * Fixed Chrome rendering bug [(rctoris)](https://github.com/rctoris/)

2014-07-28 - **0.3.0**
 * Polygon shape added [(vliedel)](https://github.com/vliedel/)
 * Rotated navigation arrow, such that it points east at 0 rotation [(vliedel)](https://github.com/vliedel/)
 * Grid added [(rbonghi)](https://github.com/rbonghi/)

2013-05-07 - **r2**
 * Added static map service client [(jihoonl)](https://github.com/jihoonl/)
 * OccupancyGrid now sets correct translation offset [(rctoris)](https://github.com/rctoris/)
 * Updated to roslibjs r6 [(rctoris)](https://github.com/rctoris/)

2013-04-15 - **r1**
 * Initial development of ROS2D [(rctoris)](https://github.com/rctoris/)
