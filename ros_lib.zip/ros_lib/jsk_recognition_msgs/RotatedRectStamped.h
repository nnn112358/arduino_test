#ifndef _ROS_jsk_recognition_msgs_RotatedRectStamped_h
#define _ROS_jsk_recognition_msgs_RotatedRectStamped_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "std_msgs/Header.h"
#include "jsk_recognition_msgs/RotatedRect.h"

namespace jsk_recognition_msgs
{

  class RotatedRectStamped : public ros::Msg
  {
    public:
      std_msgs::Header header;
      jsk_recognition_msgs::RotatedRect rect;

    RotatedRectStamped():
      header(),
      rect()
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      offset += this->header.serialize(outbuffer + offset);
      offset += this->rect.serialize(outbuffer + offset);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      offset += this->header.deserialize(inbuffer + offset);
      offset += this->rect.deserialize(inbuffer + offset);
     return offset;
    }

    const char * getType(){ return "jsk_recognition_msgs/RotatedRectStamped"; };
    const char * getMD5(){ return "0260299b5425567e14c7b295b58829e9"; };

  };

}
#endif